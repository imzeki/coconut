Coconut is a very simple programming language. It helps break tasks down into simpler tasks to help conserve space.

In order to be used, Coconut requires a lot of recently used modules.